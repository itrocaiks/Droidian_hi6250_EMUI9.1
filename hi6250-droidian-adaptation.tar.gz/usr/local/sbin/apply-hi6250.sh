#!/bin/bash
set -e

# 1. Install pre-cached packages (iwd, libell0, iwgtk, mpv, grim, openssh-server)
dpkg -i /var/cache/apt/archives/*.deb 2>/dev/null || true
apt-get -f install -y --no-download 2>/dev/null || true

# 2. Configure Android kernel PARANOID_NETWORK socket permissions
groupadd -g 3003 aid_inet 2>/dev/null || true
groupadd -g 3004 aid_net_raw 2>/dev/null || true
usermod -aG 3003,3004 droidian 2>/dev/null || true
usermod -aG 3003,3004 _apt 2>/dev/null || true

# 3. Remove slow eMMC /swapfile in favor of full-RAM ZRAM
sed -i '/swapfile/d' /etc/fstab
rm -f /swapfile

# 4. Disable heavy background autostarts & problematic services
rm -f /etc/xdg/autostart/org.gnome.Software.desktop
systemctl mask wpa_supplicant.service
systemctl mask ofono2mm.service

# Mask user-level tracker & audiosystem-passthrough for droidian (UID 32011)
mkdir -p /home/droidian/.config/systemd/user
for u in tracker-miner-fs-3.service tracker-extract-3.service tracker-xdg-portal-3.service audiosystem-passthrough.service; do
    ln -sf /dev/null "/home/droidian/.config/systemd/user/$u"
done
chown -R 32011:32011 /home/droidian/.config

# 5. Enable custom Honor 9 Lite (hi6250) & USB RNDIS services
systemctl enable iwd.service
systemctl enable zram-swap.service
systemctl enable huawei-powerkey.service
systemctl enable droidian-telnet.service
systemctl enable mtp-configfs@rndis.service
systemctl enable ssh.service 2>/dev/null || true

# 6. Refresh dynamic linker cache
ldconfig 2>/dev/null || true
